// orderOne.js

import React, { useState } from 'react';
import {Link} from 'react-router-dom'
import Header from "../Header";
// import '../Booking/OrderOnee.css'



const OrderOne = () => {
  const [formData, setFormData] = useState({
    chest: '',
    waist: '',
    hips: '',
    preferredDate: '',
    preferredTime: '',
    material: '',
    orderDetails: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your form submission logic here
    console.log('Form submitted:', formData);
  };

  return (
    <>
    <Header/>
    <div className="containerod">
      <h2 className="text-center">Tailor's Order Form</h2>
      <hr />
      <div className="row">
        <div className="col-md-6">
          <div className="form-part">
            <h3>Measurements and Sizes</h3>
            <form>
              <div className="form-group">
                <label htmlFor="chest">Chest:</label>
                <input
                  type="text"
                  className="form-control"
                  id="chest"
                  name="chest"
                  value={formData.chest}
                  onChange={handleChange}
                  placeholder="Enter chest size"
                />
              </div>
              <div className="form-group">
                <label htmlFor="waist">Waist:</label>
                <input
                  type="text"
                  className="form-control"
                  id="waist"
                  name="waist"
                  value={formData.waist}
                  onChange={handleChange}
                  placeholder="Enter waist size"
                />
              </div>
              <div className="form-group">
                <label htmlFor="hips">Hips:</label>
                <input
                  type="text"
                  className="form-control"
                  id="hips"
                  name="hips"
                  value={formData.hips}
                  onChange={handleChange}
                  placeholder="Enter hips size"
                />
              </div>
            </form>
          </div>
        </div>
        <div className="col-md-6">
          <div className="form-part">
            <h3>Order Details</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="preferredDate">Preferred Appointment Date:</label>
                <input
                  type="date"
                  name="preferredDate"
                  value={formData.preferredDate}
                  onChange={handleChange}
                  required
                />
                <label htmlFor="preferredTime">Preferred Appointment Time:</label>
                <input
                  type="time"
                  name="preferredTime"
                  value={formData.preferredTime}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="material">Material:</label>
                <input
                  type="text"
                  className="form-control"
                  id="material"
                  name="material"
                  value={formData.material}
                  onChange={handleChange}
                  placeholder="Enter material"
                />
              </div>
              <div className="form-group">
                <label htmlFor="orderDetails">Order Details:</label>
                <input
                  type="text"
                  className="form-control"
                  id="orderDetails"
                  name="orderDetails"
                  value={formData.orderDetails}
                  onChange={handleChange}
                  placeholder="Enter order details"
                />
              </div>
            </form>
          </div>
        </div>
        <Link to='/ordertwo'>
        <button type="submit" className="btn btn-primary">
                Next
        </button></Link>
      </div>
      <hr />
    </div>
    </>
  );
};

export default OrderOne;
